import React, { useState } from 'react';
import { View, TextInput, Alert, StyleSheet, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

export default function NewUserScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigation = useNavigation();

const saveUser = async () => {
  if (!email || !password || !confirmPassword) {
    Alert.alert('Error', 'All fields are required.');
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  const sanitizedEmail = email.trim().toLowerCase();

  if (!emailRegex.test(sanitizedEmail)) {
    Alert.alert('Error', 'Invalid email format.');
    return;
  }

  if (password !== confirmPassword) {
    Alert.alert('Error', 'Passwords do not match.');
    return;
  }

  try {
    const storedUsers = JSON.parse(await AsyncStorage.getItem('users')) || [];
    const userExists = storedUsers.some(user => user.email === sanitizedEmail); 

    if (userExists) {
      Alert.alert('Error', 'User with this email already exists.');
      return;
    }

    const newUser = { email: sanitizedEmail, password }; 
    const updatedUsers = [...storedUsers, newUser];
    await AsyncStorage.setItem('users', JSON.stringify(updatedUsers));

    Alert.alert('Success', 'User added successfully.');
    navigation.goBack();
  } catch (error) {
    console.log(error);
    Alert.alert('Error', 'Failed to save user.');
  }
};


  return (
    <View style={styles.mainContainer}>

      <View style={styles.header}>
        <Text style={styles.headerText}>BALABAT, John Earl P.</Text>
        <TouchableOpacity>
          <Text style={styles.plusIcon}>+</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.formContainer}>
        <Text style={styles.title}>New User</Text>
        <TextInput
          style={styles.input}
          placeholder="email"
          value={email}
          onChangeText={setEmail}
          placeholderTextColor="#999"
        />
        <TextInput
          style={styles.input}
          placeholder="password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          placeholderTextColor="#999"
        />
        <TextInput
          style={styles.input}
          placeholder="confirm password"
          secureTextEntry
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          placeholderTextColor="#999"
        />

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.saveButton} onPress={saveUser}>
            <Text style={styles.buttonText}>SAVE</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.buttonText}>CANCEL</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#FFF', 
  },
  header: {
    backgroundColor: '#ff0000',
    padding: 22,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    color: '#FFF',
    fontSize: 18,
  },
  plusIcon: {
    color: '#FFF',
    fontSize: 24,
  },
  formContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#FFF',
    marginTop: 20,
  },
  title: {
    color: '#000',
    fontSize: 22,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#999',
    padding: 10,
    marginVertical: 10,
    color: '#000',
    borderRadius: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  saveButton: {
    backgroundColor: '#00AEEF',
    padding: 15,
    flex: 1,
    marginRight: 10,
    borderRadius: 5,
  },
  cancelButton: {
    backgroundColor: '#00AEEF', 
    padding: 15,
    flex: 1,
    marginLeft: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    textAlign: 'center',
  },
});
