import React, { useState, useEffect } from 'react';
import { View, TextInput, Text, Alert, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation();

  useEffect(() => {
    // Check if initial data is already stored
    const storeInitialData = async () => {
      const storedUsers = await AsyncStorage.getItem('users');
      if (!storedUsers) {
        // Add the initial user to AsyncStorage if it doesn't exist
        const initialUsers = [{ email: 'alpha@uc.edu.ph', password: '12345' }];
        await AsyncStorage.setItem('users', JSON.stringify(initialUsers));
      }
    };

    storeInitialData(); // Store the initial user only once
  }, []);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password.');
      return;
    }

    try {
      const storedUsers = JSON.parse(await AsyncStorage.getItem('users')) || [];
      const trimmedEmail = email.trim().toLowerCase();
      const user = storedUsers.find(user => user.email.trim().toLowerCase() === trimmedEmail && 
      user.password === password);

      if (user) {
        navigation.navigate('UserSearch');
      } else {
        Alert.alert('Error', 'Invalid email or password.');
      }
    } catch (error) {
      console.log(error);
      Alert.alert('Error', 'Login failed.');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>BALABAT, John Earl P.</Text>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="email"
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          style={styles.input}
          placeholder="password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />

        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>LOGIN</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#ff0000',
    padding: 25,
  },
  headerText: {
    color: '#fff',
    fontSize: 18,
  },
  inputContainer: {
    flex: 1,
    paddingHorizontal: 30,
    marginTop: 30, 
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 15,
    marginVertical: 10,
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#00AEEF',
    padding: 17,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 19,
    fontWeight: 'bold',
  },
});
