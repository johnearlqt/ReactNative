import React, { useState, useEffect } from 'react';
import { View, TextInput, Text, Image, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation, useIsFocused } from '@react-navigation/native';

export default function UserSearchScreen() {
  const [search, setSearch] = useState('');
  const [users, setUsers] = useState([]);
  const navigation = useNavigation();
  const isFocused = useIsFocused(); 

  useEffect(() => {
    const fetchUsers = async () => {
      const storedUsers = JSON.parse(await AsyncStorage.getItem('users')) || [];
      setUsers(storedUsers); // Update the list of users
    };

    if (isFocused) {
      fetchUsers(); // Fetch users when screen is focused
    }
  }, [isFocused]);

  const filteredUsers = users.filter(user =>
    user.email.toLowerCase().includes(search.trim().toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>BALABAT, John Earl P.</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Image source={require('../assets/backButton.png')} style={styles.icon} />
          <Text style={styles.backButtonText}>back</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('NewUser')} style={styles.plusButton}>
          <Image source={require('../assets/plusButton.png')} style={styles.icon} />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search..."
          value={search}
          onChangeText={setSearch}
        />
        <Image source={require('../assets/searchIcon.png')} style={styles.searchIcon} />
      </View>
      
      <FlatList
        data={filteredUsers}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.userContainer} 
            onPress={() => navigation.navigate('DisplayProfile', { user: item })}
          >
            <Image source={require('../assets/userButton.jpg')} style={styles.userIcon} />
            <Text style={styles.userText}>{item.email}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    backgroundColor: 'red',
    padding: 25,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerText: {
    color: '#fff',
    fontSize: 18,
    flex: 1, 
  },
  backButton: {
    position: 'absolute',
    left: 25,
    bottom: 0, 
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#fff',
    marginLeft: 5,
    fontSize: 16,
  },
  plusButton: {
    position: 'absolute',
    right: 20,
    bottom: 18, 
  },
  icon: {
    width: 24,
    height: 24,
  },
  searchContainer: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#ccc',
    margin: 10,
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
  },
  searchIcon: {
    width: 24,
    height: 24,
  },
  userContainer: {
    flexDirection: 'row',
    padding: 10,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },
  userIcon: {
    width: 40,
    height: 40,
  },
  userText: {
    marginLeft: 10,
    color: '#000', 
  },
});
