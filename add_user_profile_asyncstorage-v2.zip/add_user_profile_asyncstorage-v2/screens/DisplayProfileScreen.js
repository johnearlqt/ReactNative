import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function DisplayProfileScreen({ route }) {
  const { user } = route.params; // Get user data from navigation
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerText}>BALABAT, John Earl P.</Text>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Image source={require('../assets/backButton.png')} style={styles.icon} />
          <Text style={styles.backButtonText}>back</Text>
        </TouchableOpacity>
      </View>

      {/* User Icon */}
      <View style={styles.profileContainer}>
        <Image source={require('../assets/userButton.jpg')} style={styles.userIcon} />
        <Text style={styles.userEmail}>{user.email}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    backgroundColor: 'red',
    padding: 25,
  },
  headerText: {
    color: '#fff',
    fontSize: 18,
  },
  backButton: {
    position: 'absolute',
    left: 25,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#fff',
    marginLeft: 5,
    fontSize: 16,
  },
  icon: {
    width: 24,
    height: 24,
  },
  profileContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  userIcon: {
    width: 100,
    height: 100,
  },
  userEmail: {
    marginTop: 20,
    fontSize: 18,
    color: '#000',
  },
});
